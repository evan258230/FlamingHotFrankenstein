var class_request =
[
    [ "Request", "class_request.html#afaf8d8928de7ffff8a3767589489bd33", null ],
    [ "Request", "class_request.html#ac36b9b019b60dfece158792882a87bfb", null ],
    [ "ipIn", "class_request.html#aa83b5e8331e7f13fb5742984f955d0c1", null ],
    [ "ipOut", "class_request.html#af585c7ba4ed14c760cf8d72b232091b4", null ],
    [ "jobType", "class_request.html#ad49a0f18615ea50f9a11cd2494c93044", null ],
    [ "time", "class_request.html#a3cfb576ed0b5e08612f3de8bc7cd72e2", null ]
];