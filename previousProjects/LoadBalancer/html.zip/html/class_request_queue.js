var class_request_queue =
[
    [ "isEmpty", "class_request_queue.html#a10a42d2206616c80907517d3c6ed8245", null ],
    [ "pop", "class_request_queue.html#a46f0a411a4ae00af3712e306ea2348c6", null ],
    [ "push", "class_request_queue.html#adbbda18f07fbfe710664e3096b9c552f", null ],
    [ "size", "class_request_queue.html#ac2a2a546ac5579e45ca11f433a8a804c", null ]
];