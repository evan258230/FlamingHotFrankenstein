var searchData=
[
  ['request_0',['Request',['../class_request.html#afaf8d8928de7ffff8a3767589489bd33',1,'Request::Request()'],['../class_request.html#ac36b9b019b60dfece158792882a87bfb',1,'Request::Request(std::string in, std::string out, int t, char type)']]]
];
