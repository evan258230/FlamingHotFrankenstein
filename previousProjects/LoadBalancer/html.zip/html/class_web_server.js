var class_web_server =
[
    [ "WebServer", "class_web_server.html#ad053f4e1808a3c10c7522d0dbbbc031a", null ],
    [ "addRequest", "class_web_server.html#a0bceffa30f9ea50dc30ba02ff9cc328c", null ],
    [ "busy", "class_web_server.html#a0b771f7179acbf93f61bff67fef96053", null ],
    [ "getRequest", "class_web_server.html#aa5e1fe7b67c6ef5bef717d774ccb53f9", null ],
    [ "tick", "class_web_server.html#af3fbbb5c55f04c42e951f72c6cb6e9e9", null ]
];