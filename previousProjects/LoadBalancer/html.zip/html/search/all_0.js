var searchData=
[
  ['addrequest_0',['addRequest',['../class_load_balancer.html#a3e3ee400ef4487a03511d073e45e7c84',1,'LoadBalancer::addRequest()'],['../class_web_server.html#a0bceffa30f9ea50dc30ba02ff9cc328c',1,'WebServer::addRequest()']]],
  ['adjustservers_1',['adjustServers',['../class_load_balancer.html#a43b5cdf41790ba4b968ec69c18f2c98d',1,'LoadBalancer']]]
];
